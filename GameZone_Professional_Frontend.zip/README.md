# GameZone Frontend

Professional gaming-zone frontend built with HTML5, CSS3 and vanilla JavaScript.

## Pages (10)
1. index.html — Landing/Home
2. games.html — Games overview/catalog
3. register.html — Player registration
4. login.html — Role-based demo login
5. user-dashboard.html — Player dashboard
6. manager-dashboard.html — Manager dashboard
7. admin-dashboard.html — Admin dashboard
8. support-dashboard.html — Support Care dashboard
9. owner-dashboard.html — Owner command center
10. about.html — About / system overview

## Demo
Open `index.html` in a browser. Use Login to select a role:
- User / Player
- Manager
- Admin
- Support Care
- Owner

This is a frontend prototype. Data is stored only in browser localStorage. A backend/API/database can be connected later.
