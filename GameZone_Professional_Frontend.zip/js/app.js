const games=[
{name:'Valorant',genre:'FPS',icon:'🎯',desc:'Tactical 5v5 competitive shooter.'},
{name:'EA Sports FC 26',genre:'Sports',icon:'⚽',desc:'Competitive football experience.'},
{name:'GTA V',genre:'Action',icon:'🏙️',desc:'Open-world action and online play.'},
{name:'Forza Horizon 5',genre:'Racing',icon:'🏎️',desc:'High-speed open-world racing.'},
{name:'Tekken 8',genre:'Fighting',icon:'🥊',desc:'Next-generation fighting battles.'},
{name:'Call of Duty',genre:'FPS',icon:'🔫',desc:'Fast-paced multiplayer combat.'},
{name:'PUBG',genre:'Battle Royale',icon:'🪖',desc:'Last-player-standing survival.'},
{name:'Rocket League',genre:'Sports',icon:'🚗',desc:'Cars, football and crazy goals.'}];

function nav(){document.getElementById('navbar').innerHTML=`<nav class="navbar"><a class="brand" href="index.html">GAME<span>ZONE</span><i>●</i></a><div class="navlinks"><a href="index.html">Home</a><a href="games.html">Games</a><a href="register.html">Register</a><a href="about.html">About</a></div><div class="nav-actions"><a class="btn ghost" href="login.html">Login</a><a class="btn primary" href="register.html">Join Now</a></div></nav>`}
function footer(){const f=document.getElementById('footer');if(f)f.innerHTML=`<footer>© 2026 GameZone Arena · Frontend Demo · Built with HTML, CSS & JavaScript</footer>`}
function cards(list){return list.map(g=>`<article class="game-card"><div class="game-cover">${g.icon}</div><div class="game-info"><span class="tag">${g.genre}</span><h3>${g.name}</h3><p>${g.desc}</p><button class="small-btn" onclick="toast('${g.name} selected')">View Game</button></div></article>`).join('')}
function toast(msg){const x=document.createElement('div');x.className='toast';x.textContent=msg;document.body.appendChild(x);setTimeout(()=>x.remove(),2200)}
function logout(){localStorage.removeItem('gzRole');location.href='login.html'}
document.addEventListener('DOMContentLoaded',()=>{
 nav();footer();
 const fg=document.getElementById('featuredGames');if(fg)fg.innerHTML=cards(games.slice(0,4));
 const gg=document.getElementById('gamesGrid'),search=document.getElementById('gameSearch'),filter=document.getElementById('gameFilter');
 function render(){if(!gg)return;const q=(search.value||'').toLowerCase(),f=filter.value;gg.innerHTML=cards(games.filter(g=>(g.name.toLowerCase().includes(q)||g.genre.toLowerCase().includes(q))&&(f==='all'||g.genre===f)))} 
 if(gg){search.oninput=render;filter.onchange=render;render()}
 const rf=document.getElementById('registerForm');if(rf)rf.onsubmit=e=>{e.preventDefault();const data=Object.fromEntries(new FormData(rf));localStorage.setItem('gzUser',JSON.stringify(data));localStorage.setItem('gzRole','user');toast('Account created! Opening dashboard...');setTimeout(()=>location.href='user-dashboard.html',900)}
 const lf=document.getElementById('loginForm');if(lf)lf.onsubmit=e=>{e.preventDefault();const role=new FormData(lf).get('role');localStorage.setItem('gzRole',role);location.href=`${role}-dashboard.html`}
});